// LOADS DA MAP

// Loads and controls the interactive Spline campus map.

import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../navigation/models/node_model.dart';

class HomeSplineMap extends StatefulWidget {
  const HomeSplineMap({
    required this.selectedFloor,
    required this.selectionRequest,
    this.visibleRouteEdgeIds = const <String>{},
    this.routeStartNode,
    this.routeDestinationNode,
    super.key,
  });

  final String selectedFloor;

  /// Increases whenever a floor toggle is tapped.
  ///
  /// This means the selected floor can be requested again to recenter it.
  final int selectionRequest;

  /// Names of the Spline edge objects that form the route currently shown.
  ///
  /// Each value must exactly match an edge_id in Supabase and an object name
  /// in Spline, for example E_GN0_GN1.
  final Set<String> visibleRouteEdgeIds;

  /// Endpoints are sent to Spline only while a calculated route is active.
  /// Their coordinates position the Spline-owned route marker groups.
  final NodeModel? routeStartNode;
  final NodeModel? routeDestinationNode;

  @override
  State<HomeSplineMap> createState() => _HomeSplineMapState();
}

class _HomeSplineMapState extends State<HomeSplineMap> {
  static const String _sceneUrl =
      'https://prod.spline.design/Aezweir8wJSnirTX/scene.splinecode';

  static const String _runtimeUrl =
      'https://unpkg.com/@splinetool/runtime@1.12.98/build/runtime.js';

  /// Must be slightly longer than the camera transition configured in Spline.
  /// While a transition is running, the newest requested floor is queued.
  static const Duration _cameraTransitionDuration = Duration(milliseconds: 900);

  late final WebViewController _controller;

  bool _isLoading = true;
  bool _isSplineReady = false;
  bool _isSwitchingFloor = false;
  String? _pendingFloor;
  String? _loadError;

  String get _splineHtml {
    return '''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">

  <meta
    name="viewport"
    content="width=device-width, initial-scale=1, maximum-scale=1"
  >

  <style>
    html,
    body {
      width: 100%;
      height: 100%;
      margin: 0;
      overflow: hidden;
      background: #E8E8E8;
    }

    #canvas3d {
      width: 100%;
      height: 100%;
      display: block;
      touch-action: none;
    }
  </style>
</head>

<body>
  <canvas id="canvas3d"></canvas>

  <script type="module">
    import { Application } from '$_runtimeUrl';

    const canvas = document.getElementById('canvas3d');
    const spline = new Application(canvas);

    const routeBaseState = 'Base State';
    const routeVisibleState = 'ROUTE_VISIBLE';
    const startMarkerName = 'ROUTE_START_MARKER';
    const destinationMarkerName = 'ROUTE_DESTINATION_MARKER';

    function sendToFlutter(message) {
      if (window.SplineBridge) {
        window.SplineBridge.postMessage(message);
      }
    }

    const visibleRouteEdges = new Set();

    function findRouteEdge(edgeId) {
      return spline.findObjectByName(edgeId);
    }

    function setRouteEdgeState(edgeObject, stateName) {
      try {
        /*
         * Assigning the state directly is deterministic. It does not depend
         * on the previous Key Down animation being reversible.
         */
        edgeObject.state = stateName;
        return true;
      } catch (error) {
        sendToFlutter(
          'route-error:' + edgeObject.name + ': ' + String(error)
        );
        return false;
      }
    }

    window.setRouteEdges = function(edgeIds) {
      if (!Array.isArray(edgeIds)) {
        sendToFlutter('route-error:Expected an array of edge IDs.');
        return false;
      }

      const requestedEdges = new Set(
        edgeIds
          .map(function(edgeId) {
            return String(edgeId).trim();
          })
          .filter(function(edgeId) {
            return edgeId.length > 0;
          })
      );

      /*
       * Reset every Spline route-edge object before showing the new route.
       * This also clears an edge that was made visible by a manual R-key test
       * and was therefore never recorded in visibleRouteEdges.
       */
      spline.getAllObjects().forEach(function(object) {
        if (object.name && object.name.startsWith('E_')) {
          setRouteEdgeState(object, routeBaseState);
        }
      });

      visibleRouteEdges.clear();

      const missingEdges = [];

      /* Show only the edges belonging to the latest RouteResult. */
      requestedEdges.forEach(function(requestedEdge) {
        const edgeObject = findRouteEdge(requestedEdge);

        if (!edgeObject) {
          missingEdges.push(requestedEdge);
          return;
        }

        if (setRouteEdgeState(edgeObject, routeVisibleState)) {
          visibleRouteEdges.add(requestedEdge);
        }
      });

      spline.requestRender();

      sendToFlutter(
        'route-updated:' + Array.from(visibleRouteEdges).join(',')
      );

      /* Send missing IDs last so route-updated cannot erase the error. */
      missingEdges.forEach(function(edgeId) {
        sendToFlutter('missing-edge:' + edgeId);
      });

      return true;
    };

    function updateRouteMarker(markerName, endpoint) {
      const marker = spline.findObjectByName(markerName);

      if (!marker) {
        sendToFlutter('missing-marker:' + markerName);
        return false;
      }

      if (endpoint === null) {
        marker.hide();
        sendToFlutter('marker-hidden:' + markerName);
        return true;
      }

      const coordinates = [endpoint.x, endpoint.y, endpoint.z];
      const hasValidCoordinates = coordinates.every(Number.isFinite);

      if (!hasValidCoordinates) {
        marker.hide();
        sendToFlutter('marker-error:' + endpoint.nodeId);
        return false;
      }

      marker.position.x = endpoint.x;
      marker.position.y = endpoint.y;
      marker.position.z = endpoint.z;
      marker.show();

      sendToFlutter(
        'marker-positioned:' +
          markerName + ':' + endpoint.nodeId + ':' +
          endpoint.x + ',' + endpoint.y + ',' + endpoint.z
      );
      return true;
    }

    window.setRouteEndpoints = function(startEndpoint, destinationEndpoint) {
      updateRouteMarker(startMarkerName, startEndpoint);
      updateRouteMarker(destinationMarkerName, destinationEndpoint);
      spline.requestRender();
      sendToFlutter('markers-updated');
      return true;
    };

    /*
     * ---------------------------------------------------------------------
     * REMEMBERED FLOOR CAMERA TRANSFORMS
     * ---------------------------------------------------------------------
     * Diagnostic logging (see chat history) confirmed that spline._camera
     * is the single, real, rendered camera: its position/rotation/
     * quaternion/zoom genuinely change with both orbit and floor switches.
     * spline._camera.orthoCamera / .perspCamera are inert templates always
     * stuck at identity — not involved in rendering. No separate
     * orbit-controls object (something exposing target/update()/enabled)
     * was found anywhere reachable from `spline`, so orbit most likely
     * writes straight into spline._camera itself.
     *
     * That means replaying the Mouse Up event asks Spline to re-run its own
     * animated Switch Camera tween starting from wherever the camera
     * currently sits — and if that tween gets interrupted (another dispatch
     * fired mid-flight, or it overlaps an in-progress drag), it can settle
     * slightly off. That matches "a little glitchy" rather than "broken".
     *
     * Fix: the first time a floor is requested, still use Spline's own
     * dispatch()-based transition (so it plays a real animation), then once
     * it should have settled, remember spline._camera's actual resulting
     * transform for that floor name. Every later request for that same
     * floor skips dispatch() entirely and animates spline._camera straight
     * to the remembered transform ourselves — never touching Spline's own
     * transition or orbit machinery, so nothing orbit does can corrupt it.
     */
    const floorCameraCache = {};
    let cameraTweenFrame = null;

    function cloneCameraTransform() {
      const camera = spline._camera;
      return {
        position: {
          x: camera.position.x,
          y: camera.position.y,
          z: camera.position.z,
        },
        quaternion: {
          x: camera.quaternion.x,
          y: camera.quaternion.y,
          z: camera.quaternion.z,
          w: camera.quaternion.w,
        },
        zoom: camera.zoom,
      };
    }

    function lerp(a, b, t) {
      return a + (b - a) * t;
    }

    function tweenCameraTo(targetTransform, durationMs, onComplete) {
      if (cameraTweenFrame !== null) {
        cancelAnimationFrame(cameraTweenFrame);
        cameraTweenFrame = null;
      }

      const camera = spline._camera;
      const start = cloneCameraTransform();
      const startTime = performance.now();

      function step(now) {
        const elapsed = now - startTime;
        const t = Math.min(1, durationMs <= 0 ? 1 : elapsed / durationMs);
        // Ease-out cubic, close to the feel of Spline's own default
        // transition curve.
        const eased = 1 - Math.pow(1 - t, 3);

        camera.position.x = lerp(start.position.x, targetTransform.position.x, eased);
        camera.position.y = lerp(start.position.y, targetTransform.position.y, eased);
        camera.position.z = lerp(start.position.z, targetTransform.position.z, eased);

        const qx = lerp(start.quaternion.x, targetTransform.quaternion.x, eased);
        const qy = lerp(start.quaternion.y, targetTransform.quaternion.y, eased);
        const qz = lerp(start.quaternion.z, targetTransform.quaternion.z, eased);
        const qw = lerp(start.quaternion.w, targetTransform.quaternion.w, eased);
        const qLen = Math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw) || 1;
        camera.quaternion.x = qx / qLen;
        camera.quaternion.y = qy / qLen;
        camera.quaternion.z = qz / qLen;
        camera.quaternion.w = qw / qLen;

        camera.zoom = lerp(start.zoom, targetTransform.zoom, eased);

        // Both are safe no-ops if the runtime's camera object doesn't
        // expose them; harmless either way, but keep any cached
        // matrix/projection state consistent if it does.
        if (typeof camera.updateMatrixWorld === 'function') {
          camera.updateMatrixWorld(true);
        }
        if (typeof camera.updateProjectionMatrix === 'function') {
          camera.updateProjectionMatrix();
        }

        spline.requestRender();

        if (t < 1) {
          cameraTweenFrame = requestAnimationFrame(step);
        } else {
          cameraTweenFrame = null;
          if (onComplete) onComplete();
        }
      }

      cameraTweenFrame = requestAnimationFrame(step);
    }

    function replayMouseUpEvent(floorObject) {
      /*
       * A real canvas tap makes Spline call dispatch(), which restarts its
       * Switch Camera action. The public emitEvent() API instead calls
       * playFromCurrent(). After a floor has already finished once,
       * playFromCurrent() has nowhere left to move and the camera stays put.
       *
       * Use the same Basic Mouse Up event objects as a real tap and call their
       * replayable dispatch() method. The runtime version is pinned above so
       * this event-manager structure stays consistent.
       *
       * This is now only used the FIRST time a given floor is requested, to
       * learn its true camera transform (see floorCameraCache above). Every
       * later request for that floor bypasses this entirely.
       */
      const mouseUpEvents =
        spline.eventManager?.handlers?.Basic?.eventsPerObjects?.MouseUp?.[
          floorObject.uuid
        ];

      if (!Array.isArray(mouseUpEvents) || mouseUpEvents.length === 0) {
        return false;
      }

      mouseUpEvents.forEach(function(event) {
        event.dispatch();
      });

      return true;
    }

    window.selectFloor = function(floorName) {
      const floorObject = spline.findObjectByName(floorName);

      if (!floorObject) {
        sendToFlutter('missing:' + floorName);
        return false;
      }

      const cached = floorCameraCache[floorName];

      if (cached) {
        tweenCameraTo(cached, 500, function() {
          sendToFlutter('selected:' + floorName);
        });
        return true;
      }

      // First-ever request for this floor: use Spline's own transition so
      // it plays a real animation, then remember where it actually landed.
      const replayed = replayMouseUpEvent(floorObject);

      if (!replayed) {
        sendToFlutter('missing-event:' + floorName);
        return false;
      }

      sendToFlutter('selected:' + floorName);

      setTimeout(function() {
        floorCameraCache[floorName] = cloneCameraTransform();
        sendToFlutter('camera-cache-learned:' + floorName);
      }, 1000);

      return true;
    };

    spline
      .load('$_sceneUrl')
      .then(function() {
        const startMarker = spline.findObjectByName(startMarkerName);
        const destinationMarker = spline.findObjectByName(
          destinationMarkerName
        );

        if (startMarker) startMarker.hide();
        if (destinationMarker) destinationMarker.hide();
        spline.requestRender();
        sendToFlutter('ready');
      })
      .catch(function(error) {
        sendToFlutter('error:' + String(error));
      });
  </script>
</body>
</html>
''';
  }

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFE8E8E8))
      ..addJavaScriptChannel(
        'SplineBridge',
        onMessageReceived: _handleSplineMessage,
      );

    unawaited(_loadFreshSplineScene());
  }

  @override
  void didUpdateWidget(covariant HomeSplineMap oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.selectionRequest != widget.selectionRequest) {
      _pendingFloor = widget.selectedFloor;

      if (_isSplineReady) {
        unawaited(_sendPendingFloor());
      }
    }

    if (!setEquals(oldWidget.visibleRouteEdgeIds, widget.visibleRouteEdgeIds)) {
      if (_isSplineReady) {
        unawaited(_sendRouteEdges());
      }
    }

    final startChanged =
        oldWidget.routeStartNode?.nodeId != widget.routeStartNode?.nodeId;
    final destinationChanged =
        oldWidget.routeDestinationNode?.nodeId !=
        widget.routeDestinationNode?.nodeId;

    if ((startChanged || destinationChanged) && _isSplineReady) {
      unawaited(_sendRouteEndpoints());
    }
  }

  void _handleSplineMessage(JavaScriptMessage message) {
    if (!mounted) return;

    final value = message.message;

    debugPrint('SplineBridge received: $value');

    if (value == 'ready') {
      setState(() {
        _isSplineReady = true;
        _isLoading = false;
        _loadError = null;
      });

      unawaited(_sendPendingFloor());
      unawaited(_sendRouteEdges());
      unawaited(_sendRouteEndpoints());
      return;
    }

    if (value.startsWith('selected:')) {
      setState(() {
        _loadError = null;
      });
      return;
    }

    if (value.startsWith('missing:')) {
      final missingObject = value.substring('missing:'.length);

      setState(() {
        _loadError = 'Spline could not find the floor object "$missingObject".';
      });
      return;
    }

    if (value.startsWith('missing-event:')) {
      final floor = value.substring('missing-event:'.length);

      setState(() {
        _loadError =
            'Spline found floor "$floor", but it has no Mouse Up event.';
      });
      return;
    }

    if (value.startsWith('route-updated:')) {
      setState(() {
        _loadError = null;
      });
      return;
    }

    if (value.startsWith('missing-edge:')) {
      final edgeId = value.substring('missing-edge:'.length);

      setState(() {
        _loadError = 'Spline could not find the route edge "$edgeId".';
      });
      return;
    }

    if (value.startsWith('missing-marker:')) {
      final markerName = value.substring('missing-marker:'.length);
      debugPrint(
        'Spline route marker "$markerName" has not been added to the scene.',
      );
      return;
    }

    if (value.startsWith('marker-error:')) {
      final nodeId = value.substring('marker-error:'.length);
      debugPrint('Spline route marker has invalid coordinates for $nodeId.');
      return;
    }

    if (value.startsWith('marker-hidden:') ||
        value.startsWith('marker-positioned:')) {
      // The full message has already been printed by the debugPrint above.
      return;
    }

    if (value == 'markers-updated') {
      return;
    }

    if (value.startsWith('camera-cache-learned:')) {
      final floor = value.substring('camera-cache-learned:'.length);
      debugPrint(
        'CampusGO learned the camera transform for floor $floor; future '
        "switches to it will animate directly instead of replaying Spline's "
        'Switch Camera event.',
      );
      return;
    }

    if (value.startsWith('route-error:')) {
      final errorMessage = value.substring('route-error:'.length);

      setState(() {
        _loadError = 'Unable to update route: $errorMessage';
      });
      return;
    }

    if (value.startsWith('error:')) {
      final errorMessage = value.substring('error:'.length);

      setState(() {
        _isLoading = false;
        _isSplineReady = false;
        _loadError = 'Spline failed to load: $errorMessage';
      });
    }
  }

  Future<void> _sendPendingFloor() async {
    if (!_isSplineReady || _isSwitchingFloor) {
      return;
    }

    final floor = _pendingFloor;

    if (floor == null) {
      return;
    }

    _pendingFloor = null;
    _isSwitchingFloor = true;

    try {
      await _controller.runJavaScript(
        'window.selectFloor(${jsonEncode(floor)});',
      );

      // JavaScript receives the command immediately, but Spline's visual
      // camera transition continues afterward. Wait before sending another.
      await Future<void>.delayed(_cameraTransitionDuration);
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _loadError = 'Unable to switch to floor $floor: $error';
      });
    } finally {
      _isSwitchingFloor = false;

      // If another button was tapped during the previous transition, run the
      // newest request now instead of losing it.
      if (_pendingFloor != null) {
        unawaited(_sendPendingFloor());
      }
    }
  }

  Future<void> _sendRouteEdges() async {
    if (!_isSplineReady) {
      return;
    }

    // Sorting is not required by Spline, but makes the JavaScript command
    // deterministic and easier to inspect while debugging.
    final edgeIds = widget.visibleRouteEdgeIds.toList()..sort();

    debugPrint('Spline route sending: ${jsonEncode(edgeIds)}');

    try {
      await _controller.runJavaScript(
        'window.setRouteEdges(${jsonEncode(edgeIds)});',
      );
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _loadError = 'Unable to display the route: $error';
      });
    }
  }

  Map<String, Object>? _encodeRouteEndpoint(NodeModel? node) {
    if (node == null) return null;

    if (!node.hasCoordinates) {
      debugPrint(
        'Spline route marker skipped because ${node.nodeId} has no complete '
        'coordinates.',
      );
      return null;
    }

    return <String, Object>{
      'nodeId': node.nodeId,
      'x': node.xCoord!,
      'y': node.yCoord!,
      'z': node.zCoord!,
    };
  }

  Future<void> _sendRouteEndpoints() async {
    if (!_isSplineReady) return;

    final start = _encodeRouteEndpoint(widget.routeStartNode);
    final destination = _encodeRouteEndpoint(widget.routeDestinationNode);

    // Treat the endpoint markers as one pair. If either node has missing
    // coordinates, hide both instead of leaving only one marker visible.
    final hasCompleteEndpointPair = start != null && destination != null;
    final startPayload = hasCompleteEndpointPair ? start : null;
    final destinationPayload = hasCompleteEndpointPair ? destination : null;

    debugPrint(
      'Spline route endpoints sending: '
      'start=${jsonEncode(startPayload)}, '
      'destination=${jsonEncode(destinationPayload)}',
    );

    try {
      await _controller.runJavaScript(
        'window.setRouteEndpoints('
        '${jsonEncode(startPayload)}, ${jsonEncode(destinationPayload)}'
        ');',
      );
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _loadError = 'Unable to position the route markers: $error';
      });
    }
  }

  Future<void> _loadFreshSplineScene() async {
    try {
      await _controller.clearCache();
      await _controller.clearLocalStorage();

      await _controller.loadHtmlString(
        _splineHtml,
        baseUrl: 'https://prod.spline.design/',
      );
    } catch (error) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _isSplineReady = false;
        _loadError = 'Unable to open the campus map: $error';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Interactive campus map for ${widget.selectedFloor}',
      child: Stack(
        fit: StackFit.expand,
        children: [
          const ColoredBox(color: Color(0xFFE8E8E8)),
          WebViewWidget(controller: _controller),
          if (_isLoading)
            const ColoredBox(
              color: Color(0xFFE8E8E8),
              child: Center(child: CircularProgressIndicator()),
            ),
          if (_loadError != null)
            ColoredBox(
              color: const Color(0xFFE8E8E8),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_loadError!, textAlign: TextAlign.center),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
