import 'package:flutter/material.dart';

import '../../../shared/widgets/temporary_linked_screen.dart';

class AdminManageTimetableScreen extends StatelessWidget {
  const AdminManageTimetableScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const TemporaryLinkedScreen(
      title: 'Rooms & Availability',
      pageName: 'Rooms & Availability',
    );
  }
}
